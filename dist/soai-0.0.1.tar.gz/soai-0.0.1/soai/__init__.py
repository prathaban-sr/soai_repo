from soai.modeltrainer import ModelTrainer
from soai.models.resnet import ResNet18